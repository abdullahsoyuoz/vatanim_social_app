import 'package:flutter/material.dart';

Color appColorMainRed = Color.fromARGB(255, 206, 47, 41);
Color appColorRed = Color.fromARGB(255, 153, 35, 22);
Color appColorRedLighter = Color.fromARGB(255, 216, 46, 32);
Color appColorRedDarker = Color.fromARGB(255, 131, 33, 20);
Color appColorRedGradiantDarker = Color.fromARGB(255, 150, 35, 22);
Color appColorRedGradiantLighter = Color.fromARGB(255, 205, 44, 30);
Color appColorRedBorder = Color.fromARGB(255, 129, 42, 29);
Color appColorBlackOutlineBorder = Color.fromARGB(255, 25, 25, 25);
Color appColorGrayOutlineBorder = Color.fromARGB(255, 218, 218, 218);
Color appColorGrayDarkerOutlineBorder = Color.fromARGB(255, 130, 130, 130);
